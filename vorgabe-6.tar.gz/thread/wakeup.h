// vim: set et ts=4 sw=4:

#ifndef __WAKEUP_H__
#define __WAKEUP_H__

/*! \file
 *  \brief Enthält die Klasse WakeUp
 */

/*! \brief Interruptbehandlungsobjekt, um in MPStuBS schlafende Prozessoren
 *  mit einem IPI zu wecken, falls neue Threads aktiv wurden.
 *
 *  Nur in MPStuBS benötigt.
 */
class WakeUp
{
};

#endif /* __WAKEUP_H__ */
