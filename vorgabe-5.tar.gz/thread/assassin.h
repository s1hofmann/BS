// vim: set et ts=4 sw=4:

/*! \file
 *  \brief Enthält die Klasse Assassin
 */

#ifndef __assassin_h__
#define __assassin_h__

#endif
