// vim: set et ts=4 sw=4:

/*! \file
 *  \brief Enthält die Klasse Watch
 */

#ifndef __watch_include__
#define __watch_include__

/* INCLUDES */

#include "types.h"
#include "guard/gate.h"

/*! \brief Interruptbehandlung für Timerinterrupts.
 *
 *  Die Klasse Watch sorgt für die Behandlung der Zeitgeberunterbrechungen,
 *  indem sie eine Zeitscheibe verwaltet und gegebenenfalls einen Threadwechsel
 *  auslöst.
 */
class Watch
{
private:
    Watch (const Watch &copy); // Verhindere Kopieren
};

#endif
