// vim: set et ts=4 sw=4:

/*! \file
 *  \brief Enthält die Klasse Thread
 */
#ifndef __thread_include__
#define __thread_include__

#include "machine/toc.h"

class Thread
{

};

#endif
