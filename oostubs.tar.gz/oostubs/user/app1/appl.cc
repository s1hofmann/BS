
// vim: set et ts=4 sw=4:

#include "user/app1/appl.h"
 
void Application::action ()
{
     
}
