
// vim: set et ts=4 sw=4:

#include "object/o_stream.h"

